<?php

namespace App\Controllers;

use \App\Auth;
use \Core\View;
use \App\Models\Item;
use \App\Models\Gallery;
use \App\Models\User;
use \App\Crypto;
use \App\Flash;

/**
 * Items controller (example)
 *
 * PHP version 7.0
 */
//class Items extends \Core\Controller
class Items extends Authenticated
{

    /**
     * Require the user to be authenticated before giving access to all methods in the controller
     *
     * @return void
     */
    protected function before()
    {
        $this->requireLogin();
        $this->user = Auth::getUser();
        $this->user->phone = Crypto::decrypt($this->user->phone); //MOVE TO METHOD WHICH REQUIRE IT
    }

    /**
     * Items index
     *
     * @return void
     */
    public function indexAction()
    {
        View::renderTemplate('Items/index.html');
    }

    /**
     * Add a new item
     *
     * @return void
     */
    public function newAction()
    {
        View::renderTemplate('Item/new.html', ['user' => $this->user]);
    }

    /**
     * create new item 
     *
     * @return void
     */
    public function createAction()
    {
        $item = new Item($_POST); //create new object of App\Model\Item
        if ($item->save($this->user, $_FILES['img'])) {
            Flash::addMessage('Обьявление добавлено успешно! :)');
            $this->redirect('/');
        } else {
            Flash::addMessage('Произошла ошибка, попробуйте еще раз.', Flash::WARNING);
            View::renderTemplate('Item/new.html', ['user' => $this->user, 'item' => $item]);
        }
    }

    /**
     * show one specific item model
     *
     * @return void
     */
    public function showAction()
    {
        if(isset($_GET['id'])) {
            $item_ = new Item;
            $item = $item_->findByID($_GET['id']);

            $favItems = $item_->findFavItemsId($this->user->id);
            $isFav = false;
            foreach ( $favItems as $favItem ) {
                if ( $favItem['item_id'] == $item->item_id ) {
                    $isFav = true;
                }
            }

            if ($item) {
                View::renderTemplate('Item/show.html', ['item' => $item, 'isFav' =>  $isFav]);
            } else {
                Flash::addMessage('Обьявление не найдено.', Flash::WARNING);
                $this->redirect('/');
            }
        } else {
            $this->redirect('/');
        }
    }

    /**
     * Edit item
     *
     * @return void
     */ 
    public function editAction()
    {
        if(isset($_GET['id'])) {
            $item_ = new Item;
            if ($item_->verifyOwner($this->user->id, $_GET['id'])) {
                $targetItem = $item_->findByID($_GET['id']);
                View::renderTemplate('Item/edit.html', [ 'item' => $targetItem]);
            } else {
                Flash::addMessage('В доступе отказано.', Flash::WARNING);
                $this->redirect('/');
            }
        } else {
            $this->redirect('/');
        }
    }
    
    /**
     * Update item
     *
     * @return void
     */ 
    public function updateAction() 
    {
        $itemNew = new Item($_POST);
        $item = $itemNew->findByID( $_POST['item_id']);
        if ($item->update($_FILES['img'], $itemNew, $this->user->id)) {
            Flash::addMessage('Обьявление изменено успешно! :)');
            $this->redirect('/Profile/myItems');
        } else {
            Flash::addMessage('Произошла ошибка, попробуйте еще раз.', Flash::WARNING);
            View::renderTemplate('Item/edit.html', [ 'item' => $item]);
        }
    }

    /**
     * delete item
     *
     * @return void
     */ 
    public function delItemAction()
    {
        if ( isset($_GET['delItemId']) ) {
            $item_ = new Item;
            if ( $item_->delItem($_GET['delItemId']) ) {
                Flash::addMessage('Обьявление удалено успешно.');
            } else {
                Flash::addMessage('Произошла ошибка, попробуйте еще раз.', Flash::WARNING);
            }
            $this->redirect('/Profile/myItems');
        }
    }

    /**
     * search item by filter
     *
     * @return void
     */ 
    public function searchAction()
    {
        //TODO
        View::renderTemplate('Item/search.html');
    }

}
