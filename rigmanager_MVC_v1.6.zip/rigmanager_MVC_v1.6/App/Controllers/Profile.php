<?php

namespace App\Controllers;

use \Core\View;
use \App\Auth;
use \App\Flash;
use \App\Crypto;
use \App\Models\Item;

/**
 * Profile controller
 *
 * PHP version 7.0
 */
class Profile extends Authenticated
{

    /**
     * Before filter - called before each action method
     *
     * @return void
     */
    protected function before()
    {
        parent::before();

        $this->user = Auth::getUser();
    }

    /**
     * Show the profile
     *
     * @return void
     */
    public function showAction()
    {
        $this->user->phone = Crypto::decrypt($this->user->phone);
        View::renderTemplate('Profile/show.html', [
            'user' => $this->user
        ]);
    }

    /**
     * Show the form for editing the profile
     *
     * @return void
     */
    public function editAction()
    {
        $this->user->phone = Crypto::decrypt($this->user->phone);
        View::renderTemplate('Profile/edit.html', ['user' => $this->user]);
    }

    /**
     * Update the profile
     *
     * @return void
     */
    public function updateAction()
    {
        var_dump($_FILES);
        if ($this->user->updateProfile($_POST, $_FILES['ava'])) {
            Flash::addMessage('Изменения сохранены!');
            $this->redirect('/profile/show');
        } else {
            Flash::addMessage('Произошла ошибка, попробуйте еще раз.', Flash::WARNING);
            View::renderTemplate('Profile/edit.html', ['user' => $this->user]);

        }
    }

    public function favAction() {
        if ( isset($_POST['item_id']) ) {
            $itemID = $_POST['item_id'];
            $item = new Item; 
            $item->checkFav($itemID, $this->user->id); //check if its in db then delete, if not in db, then add
        } else {
            echo 'Произошла ошибка.';
        }
    }

    public function removeFavAction()
    {
        if ( isset($_POST['item_id']) ) {
            $itemID = $_POST['item_id'];
            $item = new Item; 
            $item->removeFav($itemID, $this->user->id);
        } else {
            echo 'Произошла ошибка.';
        }
    }

    public function favItemsAction() {
        $item = new Item;
        $items = $item->findFavItems($this->user->id);
        View::renderTemplate('Profile/favItems.html', ['items_list' => $items]);
    }

    public function myItemsAction() {
        $item = new Item;
        $items = $item->findByUserID($this->user->id);
        View::renderTemplate('Profile/myItems.html', ['items_list' => $items]);
    }

    public function favAmountAction() {
        $item = new Item; 
        $item->favAmount($this->user->id);
    }
}
