<?php

namespace App\Controllers;

use \Core\View;
use \App\Models\User;
use \App\Auth;
use \App\Flash;

/**
 * Login controller
 *
 * PHP version 7.0
 */
class Guest extends \Core\Controller
{

    
    public function addToFavAction() {
        $item_id = null;
        if ( isset($_POST['item_id']) ) {
            $item_id = $_POST['item_id'];
        }
        if ( Auth::getUser() ) {
            echo "$item_id";
            $this->redirect("/profile/addToFav?id=$item_id");
        } else {
            echo "DEMO: item $item_id added to guest list";
        }
    }

    public function testAction() {
        $var = 2;
        $var + 2;
    }

}