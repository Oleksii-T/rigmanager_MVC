<?php

namespace App\Models;

use PDO;
use \Core\View;
use \App\Crypto;
use \App\Flash;



/**
 * User model
 *
 * PHP version 7.0
 */
class Item extends \Core\Model
{
    /**
     * Class constructor
     *
     * @param array $data  Initial property values (optional)
     *
     * @return void
     */
    public function __construct($data = [])
    {
        foreach ($data as $key => $value) {
            $this->$key = $value;
        };
    }

    /**
     * Error messages
     *
     * @var array
     */
    public $errors = [];

    /**
     * Save the item model with the current property values
     *
     * @return boolean  True if the user was saved, false otherwise
     */
    public function save($user, $file)
    {
        $this->validate(); //server side validation

        if (empty($this->errors)) {
            $sql = 'INSERT INTO items (user_id, title, tag, description, user_name, user_email, user_phone, file_path1, file_path2, file_path3, file_path4, file_path5)
            VALUES (:user_id, :title, :tag, :description, :user_name, :user_email, :user_phone, :file_path1, :file_path2, :file_path3, :file_path4, :file_path5)';
            
            $db = static::getDB();
            
            $stmt = $db->prepare($sql);

            $stmt->bindValue(':user_id', $user->id, PDO::PARAM_INT);
            $stmt->bindValue(':title', $this->title, PDO::PARAM_STR);
            $stmt->bindValue(':tag', $this->tag, PDO::PARAM_STR);
            $stmt->bindValue(':user_name', $user->name, PDO::PARAM_STR);
            $stmt->bindValue(':user_email', $this->user_email, PDO::PARAM_STR);
            $stmt->bindValue(':user_phone', $this->user_phone, PDO::PARAM_STR);
            $stmt->bindValue(':description', $this->description, PDO::PARAM_STR);
            $stmt->bindValue(':file_path1', null, PDO::PARAM_STR); //pre define all file to null
            $stmt->bindValue(':file_path2', null, PDO::PARAM_STR);
            $stmt->bindValue(':file_path3', null, PDO::PARAM_STR);
            $stmt->bindValue(':file_path4', null, PDO::PARAM_STR);
            $stmt->bindValue(':file_path5', null, PDO::PARAM_STR);
            //Time stamp is added automaticatly...
 
            //parse files
            if ( $file['name'][0] != '' ) { //if there is a file
                $this->validateImg($file); //check all files at ones if only one is invalid return false
                
                $targetDir = "media/$user->id/"; //this is directory where all uploaded files going. files sorted by user_id
                if ( !is_dir($targetDir) ) { //if there is no such dir create one
                    if ( !mkdir($targetDir) ) {
                        $this->errors[] = 'Sorry, there was an error uploading your file.'; //technicaly problem in creating dir not in uploading
                        return false;
                    }
                }

                if ( empty($this->errors) ) { //if no errors was detected
                    $i = 1; //counter
                    foreach($file['name'] as $key=>$val){ //loop through each submited image and upload it
                        $image_name = $file['name'][$key];
                        $tmp_name   = $file['tmp_name'][$key];
                        $size       = $file['size'][$key];
                        $type       = $file['type'][$key];
                        $error      = $file['error'][$key];

                        $fileName = basename($image_name);
                        $fileEx = pathinfo($fileName,PATHINFO_EXTENSION);
                        $fileName = uniqid('', true) . "." . $fileEx; //change file name to random sting with its ext   
        
                        $targetFilePath = $targetDir . $fileName; //full path to file
                        if ( move_uploaded_file($tmp_name, $targetFilePath) ) { //if upload to server succeed, commit reference to DB    
                            $stmt->bindValue(":file_path$i", "/" . $targetFilePath, PDO::PARAM_STR);
                        } else {
                            Flash::addMessage("Произошла ошибка с загрузкой '$fileName'. Обьявление было принято. 
                            Попытайтесь добавить фото через настройки обьявления еще раз.", Flash::WARNING);
                        }
                        $i++;
                    }
                } else {
                    return false;
                }
            }
            return $stmt->execute();          
        }
        return false;
    }

    /**
     * Validate current property values, adding valiation error messages to the errors array property
     *
     * @return void
     */
    private function validate()
    {
        // title
        if (strlen($this->title) < 10) {
            $this->errors[] = 'Заголовок: Минимум 10 символов.';
        }
        if (strlen($this->title) > 70) {
            $this->errors[] = 'Заголовок: Максимум 70 символов.';
        }
        
        // descrription
        if (strlen($this->description) < 10) {
            $this->errors[] = 'Описание: Минимум 10 символов.';
        }
        if (strlen($this->title) > 255) {
            $this->errors[] = 'Описание: Максимум 70 символов.';
        }

        //contact info
        if ( $this->user_phone=='' && $this->user_email=='' ) {
            $this->errors[] = 'Заполните одно поле контактных данных.';
        }

    }
    
    /**
     * Validate current property values, adding valiation error messages to the errors array property
     *
     * @return void
     */
    private function validateImg($file)
    { 
        //loop through each submited image and validate it
        $i = 1;
        foreach($file['name'] as $key=>$val){
            if ($i==6) {
                $this->errors[] = "Пока только 5 изображений поддерживаются.";
                return;
            }
            
            $name      = $file['name'][$key];
            $tmp_name   = $file['tmp_name'][$key];
            $size       = $file['size'][$key];
            $error      = $file['error'][$key];
            
            switch ($error) {
                case 0:
                    break;
                case 4:
                    $this->errors[] = "$name. No file sent.";
                case 1:
                case 2:
                    $this->errors[] = "$name. Exceeded filesize limit.";
                default:
                    $this->errors[] = "$name. Unknown errors.";
            }
                
            if ($size > 1048576) {
                $this->errors[] = "$name. Exceeded filesize limit.(1мб макс)";
            }
            
            // IMAGETYPE_JPEG as well verify .jpg files
            if ( exif_imagetype($tmp_name) != IMAGETYPE_JPEG && exif_imagetype($tmp_name) != IMAGETYPE_PNG ) {
                $this->errors[] = "$name. Sorry, only images files are allowed to upload";
            }
            $i++;
        }
        
    }
    
    public function getAll()
    {
        $sql = 'SELECT * FROM items ORDER BY item_id DESC';
        
        $db = static::getDB();
        $stmt = $db->prepare($sql);

        $stmt->setFetchMode(PDO::FETCH_CLASS, get_called_class());

        $stmt->execute();
        return $stmt->fetchAll();
    }
    
    public function verifyOwner($user_id, $item_id) 
    {
        $targetItem = $this->findByID($item_id);
        return $targetItem->user_id==$user_id ? true : false;
    }
    
    public function findByID($id) 
    {
        $sql = 'SELECT * FROM items WHERE item_id = :id';
        
        $db = static::getDB();
        $stmt = $db->prepare($sql);
        $stmt->bindValue(':id', $id, PDO::PARAM_INT);
        
        $stmt->setFetchMode(PDO::FETCH_CLASS, get_called_class());
        
        $stmt->execute();
        
        return $stmt->fetch();
    }

    public function findByUserID($id) 
    {
        $sql = 'SELECT * FROM items WHERE user_id = :id';
        
        $db = static::getDB();
        $stmt = $db->prepare($sql);
        $stmt->bindValue(':id', $id, PDO::PARAM_INT);
        
        $stmt->setFetchMode(PDO::FETCH_CLASS, get_called_class());
        
        $stmt->execute();
        
        return $stmt->fetchAll();
    }
    
    /**
     * Update the user's item
     *
     * @param array $data Data from the edit profile form
     *
     * @return boolean  True if the data was updated, false otherwise
     */
    public function update($file, $newItem)
    {
        //get old item
        $newItem->validate();
        if (empty($this->errors)) {
            
            //rewrite values if it was changed
            $this->title = $this->title==$newItem->title ? $this->title : $newItem->title;
            $this->tag = $this->tag==$newItem->tag ? $this->tag : $newItem->tag;
            $this->description = $this->description==$newItem->description ? $this->description : $newItem->description;
            $this->user_email = $this->user_email==$newItem->user_email ? $this->user_email : $newItem->user_email;
            $this->user_phone = $this->user_phone==$newItem->user_phone ? $this->user_phone : $newItem->user_phone;
            
            //commit all possible values at ones
            $sql = 'UPDATE items 
                    SET title = :title,
                        tag = :tag,
                        description = :description,
                        user_email = :user_email,
                        user_phone = :user_phone
                    WHERE item_id = :item_id';

            $db = static::getDB();
            $stmt = $db->prepare($sql);
            
            $stmt->bindValue(':title', $this->title, PDO::PARAM_STR);
            $stmt->bindValue(':tag', $this->tag, PDO::PARAM_STR);
            $stmt->bindValue(':description', $this->description, PDO::PARAM_STR);
            $stmt->bindValue(':user_email', $this->user_email, PDO::PARAM_STR);
            $stmt->bindValue(':user_phone', $this->user_phone, PDO::PARAM_STR);
            $stmt->bindValue(':item_id', $this->item_id, PDO::PARAM_INT);

            //update files
            //ADD FILES UPDATING !!!

            return $stmt->execute();
        } 
        return false;
    }
}
            /*
                public function getFour($page) {
                    if ($page!=0) { $page += 4; }
                    $sql = "SELECT * FROM items ORDER BY item_id DESC LIMIT $page,4";
            
                    $db = static::getDB();
                    $stmt = $db->prepare($sql);
            
                    $stmt->setFetchMode(PDO::FETCH_CLASS, get_called_class());
            
                    $stmt->execute();
                    return $stmt->fetchAll();
                }
                */